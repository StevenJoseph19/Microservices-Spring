package com.mycompany.conferenceapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.mycompany.conferenceapp.models.TicketType;

import java.util.List;

@RepositoryRestResource(exported = false)
public interface TicketTypeJpaRepository extends JpaRepository<TicketType, String> {
	List<TicketType> findByIncludesWorkshopTrue();
}