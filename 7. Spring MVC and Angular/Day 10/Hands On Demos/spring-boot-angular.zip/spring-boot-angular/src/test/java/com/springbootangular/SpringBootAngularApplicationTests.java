package com.springbootangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
