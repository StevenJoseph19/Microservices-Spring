package com.wiredbrain.friends;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendsApplicationTests {

	@Test
	void contextLoads() {
	}

}
