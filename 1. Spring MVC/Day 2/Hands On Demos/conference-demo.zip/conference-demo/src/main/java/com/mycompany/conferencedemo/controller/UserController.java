package com.mycompany.conferencedemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mycompany.conferencedemo.model.User;

@RestController
public class UserController {

	
	@GetMapping("/user")
	public User getUser(@RequestParam(value = "firstname", defaultValue = "Bobby") String firstname) {
		User user = new User();

		user.setFirstName(firstname);

		return user;
	}
}
