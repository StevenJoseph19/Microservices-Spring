self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "359809504cfc92126614",
    "url": "/static/js/main.35980950.chunk.js"
  },
  {
    "revision": "2bdc16058ee968cf95e7",
    "url": "/static/js/2.2bdc1605.chunk.js"
  },
  {
    "revision": "359809504cfc92126614",
    "url": "/static/css/main.bc1a0dfe.chunk.css"
  },
  {
    "revision": "2bdc16058ee968cf95e7",
    "url": "/static/css/2.183414d6.chunk.css"
  },
  {
    "revision": "f5f3a1a53ceb3cf63d9ee1fe0578abec",
    "url": "/index.html"
  }
];