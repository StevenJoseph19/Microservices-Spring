package com.mycompany.security.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;

import com.mycompany.security.service.AuthenticationSuccessHandlerImpl;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http
//			.headers()
//			.referrerPolicy().policy(ReferrerPolicy.ORIGIN)
//			.contentSecurityPolicy("script-src: https://mydomain..")
//			.contentSecurityPolicy("script-src: self")
//			frameOptions().sameOrigin()
//		.csrf().disable()
//			.headers().defaultsDisabled()
//		.headers().cacheControl().disable()
//			.and()
			.authorizeRequests()
				.mvcMatchers("/login").permitAll()
				.mvcMatchers("/support/admin").hasRole("ADMIN")
				.anyRequest()
					.authenticated()
		.and()
			.formLogin()
			   .loginPage("/login")
			   .successHandler(new AuthenticationSuccessHandlerImpl())   ;
//			 .permitAll();
//		    .httpBasic();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().mvcMatchers("/css/**","/webjars/**");
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
//		auth.ldapAuthentication()
//		auth.inMemoryAuthentication().withUser("victoria").password(encoder.encode( "password")).roles("ADMIN");
		
		auth.inMemoryAuthentication().withUser("victoria").password("{noop}password").roles("ADMIN");
	}
	
	
	
	
}
