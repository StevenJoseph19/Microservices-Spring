package com.mycompany.security.service;

import java.util.List;

import com.mycompany.security.entity.CryptoCurrency;
import com.mycompany.security.entity.Portfolio;
import com.mycompany.security.model.AddTransactionToPortfolioDto;
import com.mycompany.security.model.ListTransactionsDto;
import com.mycompany.security.model.PortfolioPositionsDto;

public interface PortfolioService {

	List<CryptoCurrency> getSupportedCryptoCurrencies();
	Portfolio getPortfolioForUsername(String username);
	PortfolioPositionsDto getPortfolioPositions(String username);
	void addTransactionToPortfolio(AddTransactionToPortfolioDto request);
	ListTransactionsDto getPortfolioTransactions(String username);
	void removeTransactionFromPortfolio(String username, String transactionId);
	void createNewPortfolio(String username);
}
