package com.mycompany.security.model;

public interface Authorities {

	static final String ROLE_USER = "ROLE_USER";
	
}
