package com.mycompany.security.service;

import static com.mycompany.security.util.AuthenticationUtil.getUsername;

import org.springframework.stereotype.Service;

import com.mycompany.security.entity.Post;
import com.mycompany.security.entity.SupportQuery;
import com.mycompany.security.model.CreateSupportQueryDto;
import com.mycompany.security.model.PostDto;
import com.mycompany.security.repository.SupportQueryRepository;

@Service
public class SupportCommandServiceNoSql implements SupportCommandService {

	private final SupportQueryRepository supportRepository;
		
	public SupportCommandServiceNoSql(SupportQueryRepository supportRepository) {
		this.supportRepository = supportRepository;
	}

	@Override
	public void createQuery(CreateSupportQueryDto query) {
		supportRepository.save(mapModelToEntity(query));
	}
	
	@Override
	public void postToQuery(PostDto model) {
		Post post = new Post(getUsername() , model.getContent(), System.currentTimeMillis());
		SupportQuery query = supportRepository.findById(model.getQueryId()).get();
		query.addPost(post);
		if(model.isResolve()) {
			query.resolve();
		}
		supportRepository.save(query);
	}
	
	@Override
	public void resolveQuery(String id) {
		SupportQuery query = supportRepository.findById(id).get();
		query.resolve();
		supportRepository.save(query);
	}
	
	private SupportQuery mapModelToEntity(CreateSupportQueryDto model) {
		SupportQuery supportQuery = new SupportQuery(getUsername() , model.getSubject());
		supportQuery.addPost(model.getContent(), getUsername() );
		return supportQuery;
	}
		
}
