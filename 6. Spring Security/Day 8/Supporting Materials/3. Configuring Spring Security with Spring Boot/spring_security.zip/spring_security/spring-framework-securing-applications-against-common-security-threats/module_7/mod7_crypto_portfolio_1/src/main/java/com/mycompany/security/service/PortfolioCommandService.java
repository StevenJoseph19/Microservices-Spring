package com.mycompany.security.service;

import com.mycompany.security.model.AddTransactionToPortfolioDto;

public interface PortfolioCommandService {

	void addTransactionToPortfolio(AddTransactionToPortfolioDto request);
	void removeTransactionFromPortfolio(String username, String transactionId);
	void createNewPortfolio(String username);
	boolean userHasAportfolio(String username);
}
