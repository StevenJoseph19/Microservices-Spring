package com.mycompany.security.service;

import com.mycompany.security.model.CreateSupportQueryDto;
import com.mycompany.security.model.PostDto;

public interface SupportCommandService {

	void createQuery(CreateSupportQueryDto query);
	void postToQuery(PostDto supportQueryPostModel);
	void resolveQuery(String id);
	
}
